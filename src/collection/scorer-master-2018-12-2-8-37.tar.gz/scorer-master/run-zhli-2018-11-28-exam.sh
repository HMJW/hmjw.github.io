verbose=$1
echo $1
python main.py --prog_dir ../2018-11-28-exam/Python_2018-11-28_2018LI/ --gold_py gold.py --func_info_list ../2018-11-28-exam/func_info_list.txt --verbose $verbose
