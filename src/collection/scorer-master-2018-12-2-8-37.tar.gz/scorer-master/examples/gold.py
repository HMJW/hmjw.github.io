def sort(nums):
    x = 1/0
    return list(sorted(nums))


def two_sum(str1, str2):
    return str1 + str2