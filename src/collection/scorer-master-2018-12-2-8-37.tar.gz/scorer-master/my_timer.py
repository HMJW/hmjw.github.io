
import signal
import time


class MyTimer(object):
    r"""Context-manager that prevents function execution from timeout.
    Example::
        >>> @MyTimer(3)
        ... def f(n):
        ...     time.sleep(n)
        >>> f(5)
        >>> with MyTimer(3):
        ...     time.sleep(5)
    """

    def __init__(self, seconds=1):
        super(MyTimer, self).__init__()
        self.seconds = seconds

    def __enter__(self):
        signal.signal(signal.SIGALRM, self.handler)
        signal.setitimer(signal.ITIMER_REAL, self.seconds)

    def __exit__(self, type, value, traceback):
        signal.setitimer(signal.ITIMER_REAL, 0)

    def __call__(self, func):
        @functools.wraps(func)
        def decorate_timeout(*args, **kwargs):
            with self:
                return func(*args, **kwargs)
                '''
                try:
                    ret = func(*args, **kwargs)
                    return ret
                except Exception as e:
                    raise(e)
                '''
        return decorate_timeout

    def handler(self, signum, frame):
        raise TimeoutError("Execution time exceeded %.10f seconds." % self.seconds)

