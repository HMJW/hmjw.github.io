egrep '^\s+\d{10}.*' exam-2018-11-28-results.txt | egrep -o '\d{8,}\s+[0-9.]*' | sort -k 1 | awk '{print $2}' > scores
