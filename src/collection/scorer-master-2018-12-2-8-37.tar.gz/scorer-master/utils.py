import os
import importlib
import inspect
import re
import sys

'''
const_func_name = 'name'
const_func_score = 'score'
const_func_max_run_time_ratio = 'max_run_time_ratio'
const_func_test_case_file_name = 'test_case_file_name'
'''


def get_all_lines(file_name):
    with open(file_name, mode='r', encoding='utf-8') as f:
        return [l.strip() for l in f if l.strip() != '']


def get_func_info(file_name):
    all_func_info = []
    all_lines = get_all_lines(file_name)
    for line in all_lines:
        tokens = re.split('\s+', line.strip())
        sz = len(tokens)
        if sz == 4:
            all_func_info.append((tokens[0], float(tokens[1]), float(tokens[2]), tokens[3])) # + '.test_cases.txt'})
        else:
            print("error line: %s in %s (%d tokens)" % (line, file_name, sz), file=sys.stderr)
    return all_func_info


def remove_py_suffix(py_file_name):
    return re.sub('\.py$', '', py_file_name) if py_file_name.endswith('.py') else py_file_name


def get_student_py_list(dir_name):
    py_list_wo_suffix = []  # no .py suffix
    all_files = os.listdir(dir_name)
    for file_name in all_files:
        if file_name.count(' ') > 0 or file_name.count('\t') > 0:
            print('file name contains space: #%s#' % file_name)
            exit(-1)
        if os.path.isfile(os.path.join(dir_name, file_name)):
            if file_name.lower().endswith('.py'):
                if file_name[-2:].lower() != file_name[-2:]:  # .PY .Py .pY -> .py
                    file_name_new = file_name[:-2] + file_name[-2:].lower()
                    os.rename(os.path.join(dir_name, file_name), os.path.join(dir_name, file_name_new))
                    file_name = file_name_new
                py_list_wo_suffix.append(remove_py_suffix(file_name))
    return py_list_wo_suffix


def get_funcs_in_one_module(module_name, verbose):
    try:
        this_module = importlib.import_module(module_name)
        return {tup[0]:tup[1] for tup in inspect.getmembers(this_module, inspect.isfunction)}
    except Exception as e:
        if verbose > 1:
            print('import module %s error: %s %s' % (module_name, type(e).__name__, e), file=sys.stderr)
        return None


def print_score_summary(py_name, total_score, func_names, func_scores):
    assert len(func_scores) == len(func_names)
    print('%15s %5.1f -> ' % (py_name, total_score), end='', file=sys.stderr)
    for name, score in zip(func_names, func_scores):
        print('%15s %5.1f\t' % (name, score), end='', file=sys.stderr)
    print(flush=True, file=sys.stderr)


def print_func_score_verbose_1(py_name, func_name, score, correct_case_cnt, total_case_cnt, verbose):
    if verbose > 0:
        print('Total score of %s for func %s: %.1f = %.1f*(%.1f/%.1f)' %
              (py_name, func_name, score*correct_case_cnt/total_case_cnt, score, correct_case_cnt, total_case_cnt),
              flush=True, file=sys.stderr)


def print_msg_verbose_2(py_name, func_name, i_input, msg, verbose):
    if verbose > 1:
        print('student %s function %s: input %d: %s' % (py_name, func_name, i_input, msg), flush=True, file=sys.stderr)


def print_a_thing_verbose_1(msg, verbose):
    if verbose > 0:
        print(msg, flush=True, file=sys.stderr)
