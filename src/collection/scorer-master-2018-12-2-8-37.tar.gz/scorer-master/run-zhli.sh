verbose=$1
echo $1
python main.py --prog_dir exam-2-zhli/ --gold_py func_123_gold.py --func_info_list func_123_func_info_list.txt --verbose $verbose
