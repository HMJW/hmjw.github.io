import sys
import argparse
import time

from utils import *
from my_timer import MyTimer

max_time_for_import_one_py = 3.0  # seconds
min_time_for_run_one_func = 0.1  # seconds, sometimes time_gap_sec*time_ratio (for gold.py) is too small


def evaluate_one_py(py_name, all_func_info, gold_funcs, verbose):
    if verbose > 0:
        print('\nStart evaluating', py_name, flush=True, file=sys.stderr)
    try:
        with MyTimer(max_time_for_import_one_py):
            this_funcs = get_funcs_in_one_module(py_name, verbose)
    except Exception as e:
        print_a_thing_verbose_1('import module %s timeout: %s %s' % (py_name, type(e).__name__, e), verbose)

    total_score = 0.
    func_scores = []
    func_names = []
    for (func_name, score, time_ratio, test_case_file_name) in all_func_info:
        func_names.append(func_name)
        if this_funcs is None or this_funcs.get(func_name) is None:
            func_scores.append(0.)
            print_a_thing_verbose_1('module %s does not contain func: %s' % (py_name, func_name), verbose)
            continue
        correct_case_cnt = 0.
        lines = get_all_lines(test_case_file_name)
        total_case_cnt = len(lines)
        gold_func = gold_funcs.get(func_name)
        assert gold_func is not None
        for i_input, one_input_line in enumerate(lines):
            #one_input_line = one_input.strip()
            #assert len(one_input_line) > 0
            one_input = eval(one_input_line)
            if type(one_input) != tuple:
                print('func %s: test case (%d) format error: %s', func_name, i_input, one_input_line)
                exit(-1)
            one_input_for_sys = eval(one_input_line)
            start_time = time.time()
            gold_result = gold_func(*one_input)
            end_time = time.time()
            time_gap_sec = end_time - start_time

            try:
                with MyTimer(max(time_gap_sec * time_ratio, min_time_for_run_one_func)):
                    result = this_funcs[func_name](*one_input_for_sys)
            except Exception as e:
                print_msg_verbose_2(py_name, func_name, i_input, '%s : %s' % (type(e).__name__, e), verbose)
                continue
            if gold_result is None:
                print(*one_input, gold_result)
            if result == gold_result:
                correct_case_cnt += 1
                print_msg_verbose_2(py_name, func_name, i_input, 'passed', verbose)
            else:
                print_msg_verbose_2(py_name, func_name, i_input, 'failed', verbose)
        this_func_score = score * correct_case_cnt / total_case_cnt
        func_scores.append(this_func_score)
        total_score += this_func_score
        print_func_score_verbose_1(py_name, func_name, score, correct_case_cnt, total_case_cnt, verbose)
    print_score_summary(py_name, total_score, func_names, func_scores)


if __name__ == '__main__':
    argparser = argparse.ArgumentParser()
    argparser.add_argument('--prog_dir', default='examples/')
    argparser.add_argument('--gold_py', default='gold.py')
    argparser.add_argument('--func_info_list', default='func_info_list.txt')
    argparser.add_argument('--verbose', type=int, default=0)
    args, extra_args = argparser.parse_known_args()

    sys.path.insert(0, args.prog_dir)
    all_func_info = get_func_info(args.func_info_list)
    py_list = get_student_py_list(args.prog_dir)

    gold_py = remove_py_suffix(args.gold_py.lower())
    gold_funcs = get_funcs_in_one_module(gold_py, args.verbose)
    assert gold_funcs is not None
    with open('log.stdout-outputs', 'w') as f:
        sys.stdout = f
        for one_py in py_list:
            evaluate_one_py(one_py, all_func_info, gold_funcs, args.verbose)

